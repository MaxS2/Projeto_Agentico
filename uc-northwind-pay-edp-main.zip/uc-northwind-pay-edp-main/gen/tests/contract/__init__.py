"""Contract tests."""
