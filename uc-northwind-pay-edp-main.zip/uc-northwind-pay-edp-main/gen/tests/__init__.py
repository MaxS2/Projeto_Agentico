"""DataGen tests."""
